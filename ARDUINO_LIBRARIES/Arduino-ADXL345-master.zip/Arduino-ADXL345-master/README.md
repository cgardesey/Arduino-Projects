Arduino-ADXL345
===============

ADXL345 Triple Axis Accelerometer Arduino Library.

![ADXL345 Processing](http://www.jarzebski.pl/media/zoom/publish/2014/01/adxl345-processing.png "ADXL345 Processing")

Tutorials: http://www.jarzebski.pl/arduino/czujniki-i-sensory/3-osiowy-akcelerometr-adxl345.html

YouTube: http://www.youtube.com/watch?v=90kI_tfOOzI

This library use I2C to communicate, 2 pins are required to interface

