# GSM_SIM900_Arduino
Send daily SMS messages using SeeedStudio GSM SIM900 and Arduino

See "Using GSM SIM900 Arduino.pdf" for full details

